window.mainApp
.controller('sudo.home', function($scope) {	
	
})
.controller('sudo.owner.new', function($scope) {	
	
})
.controller('sudo.owner.preview', function($scope, $routeParams) {	
	
})
.controller('sudo.login', function($scope) {	
	
});
