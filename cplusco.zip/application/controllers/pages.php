<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pages extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	/*
	|---------------------------
	| Get menu overall list 
	|---------------------------
	*/
	public function listmenu()
	{
		
	}

	/*
	|---------------------------
	| Get menu based on user level & permission
	|---------------------------
	| @ parameters
	| - id_user
	*/
	private function listmenu_by_userlevel()
	{
		
	}
	
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */